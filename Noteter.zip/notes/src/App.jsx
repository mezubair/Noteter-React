import React from 'react';
import CreateArea from "./components/CreateArea" // Adjust the path based on your file structure
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  return (
    <div className="App">
      <header className="App-header">
      
      </header>
     
        <CreateArea/>
        </div>
  );
}

export default App;
